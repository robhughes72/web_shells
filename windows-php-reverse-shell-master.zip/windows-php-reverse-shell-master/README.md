# windows-php-reverse-shell
Simple php reverse shell implemented using binary , based on an webshell .

Usage : change the ip and port in the  windows-php-reverse-shell.php file 
        upload , set up an listener in you machine , access the windows-php-reverse-shell.php file on the server 
        <img src="http://i.imgur.com/osI97eI.png">
        <img src="http://i.imgur.com/HULO1hU.png">
        
